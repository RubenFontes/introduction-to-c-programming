/**
 ============================================================================
 Nome      : q2-zeroADez.c
 Autor     : lincoln
 Versao    : 1.0
 Copyright : CC BY 4.0
 Descricao : Imprime todos os numeros de 0 a 10 com while, do-while e for.
 ============================================================================
 */
#include <stdio.h>

int main(void){
    int i; /* geralmente chamamos a variavel de repeticao de i */

    /* com while */
    printf("com while:\t");
    i = 0;
    while (i <= 10){
        printf(" %d", i);
        i = i + 1;
    }
    printf("\n"); /* pular a linha */

    /* com do-while */
    printf("com do-while:\t");
    i = 0;
    do{
        printf(" %d", i);
        i = i + 1;
    }while (i <= 10);
    printf("\n"); /* pular a linha */

    /* com for */
    printf("com for:\t");
    for(i = 0; i <= 10; i = i + 1){
        printf(" %d", i);
    }
    printf("\n"); /* pular a linha */

    return 0;
}
