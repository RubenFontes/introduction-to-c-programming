/**
 ============================================================================
 Nome      : q4-alternaMensagem.c
 Autor     : lincoln
 Versao    : 1.0
 Copyright : CC BY 4.0
 Descricao : Escreve na tela cem vezes, alternadamente, duas frases.
 ============================================================================
 */
#include <stdio.h>

int main(void){
    int i; /* vamos precisar para o for */

    /* Esse for executara o corpo do laco 200 vezes, pois precisamos de 100
    vezes para cada mensagem. Perceba que aqui iniciamos com 0 e a condicao
    eh i < 200 e nao i <= 200 (que executaria 201 vezes). Normalmente, em C,
    comecamos o for no 0, como escrito aqui, mas tambem seria correto se
    iniciasse i=1 e a condicao fosse i<=200. */
    for(i = 0; i < 200; i = i + 1){
        /* para alternar em 100x para cada, basta fazer um desvio para
        quando o i for par ou impar */
        if (i % 2 == 0){
            puts("Soh aprende a programar quem escreve programas.");
        }else{
            puts("Quem nao escreve programas nao aprende a programar.");
        }
    }

    return 0;
}
