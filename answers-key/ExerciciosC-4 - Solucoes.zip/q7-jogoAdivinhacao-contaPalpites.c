/**
 ============================================================================
 Nome      : q7-jogoAdivinhacao-contaPalpites.c
 Autor     : lincoln
 Versao    : 1.0
 Copyright : CC BY 4.0
 Descricao : Jogo de Adivinhacao que informa quantos palpites foram dados ate
             o acerto.
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h> /* para o numero aleatorio */
#include <time.h>   /* para o tempo, usado no numero aleatorio */

int main(void){
	int palpite, numeroCorreto; /* para ler o palpite do usuario e para armazenar o correto */
	int nPalpites; /* para contar o numero de palpites */

	nPalpites = 0; /* zerando o contador de palpites */

    srand(time(NULL)); /* inicia os numeros aleatorios */
    numeroCorreto = rand() % 100; /* pega os dois ultimos digitos de um numero aleatorio e usa como o numero correto*/

	/* fazer a leitura do primeiro palpite */
	printf("Adivinhe o numero: ");
	scanf("%d", &palpite);
	nPalpites = nPalpites + 1; /* ja incrementa o numero de palpites */

    while(palpite != numeroCorreto){
        if (palpite > numeroCorreto){
            puts("Muito alto!");
        }else{
            puts("Muito baixo!");
        }

        printf("Digite seu palpite #%d: ", nPalpites + 1); /* mostra qual eh o numero do palpite que o usuario vai inserir */
        scanf("%d", &palpite);
        nPalpites = nPalpites + 1; /* incrementa o numero de palpites dados */

    }

    /* Ao sair do laco, sabemos que o usuario digitou o palpite correto,
    informamos isso junto com o valor do contador de palpites. */
    printf("Voce ganhou apos %d palpites!", nPalpites);

	return 0;
}

