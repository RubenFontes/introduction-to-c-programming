/**
 ============================================================================
 Nome      : q5-imprimeDeAaB.c
 Autor     : lincoln
 Versao    : 1.0
 Copyright : CC BY 4.0
 Descricao : Solicita ao usuario para introduzir dois inteiros positivos, a e
             b, e imprime todos os numeros no intervalo [a, b].
 ============================================================================
 */
#include <stdio.h>

int main(void){
    int a, b; /* para os valores do usuario */
    int i; /* para o for */

    /* leiura dos valores */
    printf("Digite o valor de a: ");
    scanf("%d", &a);
    printf("Digite o valor de b (deve ser maior do que a): ");
    scanf("%d", &b);

    /* Esse for fara com que o primeiro valor de ir seja o mesmo que a, que
    incrementara a cada iteracao ate que chegue no mesmo valor de b. Como i
    eh a variavel que vai assumir todos os valores do intervalo, eh o valor
    dela que imprimimos no corpo do laco. */
    for(i = a; i <= b; i = i + 1){
        printf("%d", i);
        /* ja eh o ultimo valor? */
        if (i == b){
            printf("\n"); /* pula linha */
        }else{
            printf(", "); /* imprime uma virgula e espaco entre numeros */
        }
    }

    return 0;
}
