/**
 ============================================================================
 Nome      : q1-senha.c
 Autor     : lincoln
 Versao    : 1.0 while
 Copyright : CC BY 4.0
 Descricao : Um programa que repete a leitura de uma senha até que ela seja
             válida. Para cada leitura de senha incorreta informada, exibe
             a mensagem "Senha Invalida". Quando a senha for informada
             corretamente exibe a mensagem "Acesso Permitido".
 ============================================================================
 */
#include <stdio.h>

int main(void){
    int senha; /* variavel para ler a senha */

    /* Para fazer com while eh melhor fazer uma leitura antes. */
    printf("Digite a senha: ");
    scanf("%d", &senha);

    while (senha != 2020){
        puts("Senha Invalida"); /* ele soh executara o corpo do laco se a senha for invalida */
        printf("Digite a senha: ");
        scanf("%d", &senha);
    }

    /* O programa soh sairah do laco quando a senha estiver correta,
    portanto eh seguro exibir logo a mensagem de Acesso Permitido. */
    puts("Acesso Permitido");

    return 0;
}
