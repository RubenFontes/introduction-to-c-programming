/**
 ============================================================================
 Nome      : q7-jogoAdivinhacao-max5Palpites.c
 Autor     : lincoln
 Versao    : 1.0
 Copyright : CC BY 4.0
 Descricao : Jogo de Adivinhacao que soh permite 5 palpites.
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h> /* para o numero aleatorio */
#include <time.h>   /* para o tempo, usado no numero aleatorio */

int main(void){
	int palpite, numeroCorreto; /* para ler o palpite do usuario e para armazenar o correto */
	int nPalpites; /* para contar o numero de palpites */

	nPalpites = 0; /* zerando o contador de palpites */

    srand(time(NULL)); /* inicia os numeros aleatorios */
    numeroCorreto = rand() % 10; /* pega o ultimo digito de um numero aleatorio e usa como o numero correto*/

	/* fazer a leitura do primeiro palpite */
	printf("Adivinhe o numero: ");
	scanf("%d", &palpite);
	nPalpites = nPalpites + 1; /* ja incrementa o numero de palpites */

    /* A repeticao continua enquando nao acerta e enquanto nao foram dados
        5 palpites. Perceba o &&, as duas condicoes devem ser verdadeiras
        para que o corpo do laco seja executado. */
    while(palpite != numeroCorreto && nPalpites < 5){
        if (palpite > numeroCorreto){
            puts("Muito alto!");
        }else{
            puts("Muito baixo!");
        }

        printf("Digite seu palpite #%d: ", nPalpites + 1); /* mostra qual eh o numero do palpite que o usuario vai inserir */
        scanf("%d", &palpite);
        nPalpites = nPalpites + 1; /* incrementa o numero de palpites dados */

    }

    /* O laco serah encerrado quando qualquer uma das duas condicoes ligadas
    pelo && for falsa. Ou seja, o laco sera encerrado quando o palpite estiver
    correto (quando palpite!=numeroCorreto for falso) ou quando o usuario ja
    tiver dado 5 palpites (quando nPalpites for 5, causando nPalpites<5 ser
    falso pela primeira vez.

        Entao, ao chegar aqui, podemos verificar se o ultimo palpite dado eh
    igual ao numero correto. Caso verdadeiro, sabemos que o laco se encerrou
    porque o usuario acerto o numero e podemos informar isso. Caso contrario,
    sabemos que o laco se encerrou porque a quantidade de palpites acabaram.
     */
    if (palpite == numeroCorreto){
        printf("Voce acertou apos %d palpites!\n", nPalpites);
    }else{
        printf("Voce usou seus %d palpites e nao acertou o numero correto %d.\n",
                nPalpites, numeroCorreto);
    }

	return 0;
}

